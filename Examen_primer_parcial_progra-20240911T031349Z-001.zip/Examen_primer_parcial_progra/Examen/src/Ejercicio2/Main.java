package Ejercicio2;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        VEHICULO obj1 = new VEHICULO("Nissan","Skyline GTR R35",180000.00);
        VEHICULO obj2 = new VEHICULO("Nissan","350z 2004",8000.00);
        VEHICULO obj3 = new VEHICULO("Toyota","Corolla 1990",4000.00);

        List <VEHICULO> lista = new ArrayList<VEHICULO>();
        lista.add(obj1);
        lista.add(obj2);
        lista.add(obj3);

        System.out.println(" ");
        System.out.println("LOS SIGUIENTES VEHÍCULOS TIENEN UN PRECIO ENTRE 2500 $ y 4000 $");

        for(int i=0; i<lista.size();i++){
            if(lista.get(i).getPrecio()>=2500 && lista.get(i).getPrecio()<=4000){
                System.out.println("El vehiculo: "+lista.get(i).getMarca()+", modelo: "+lista.get(i).getModelo()+", tiene un precio de: "+lista.get(i).getPrecio()+" $");

            }
            else{

                System.out.println(" ");
            }
        }
        System.out.println("------------------------------------------------------------------------");

        double min = 1000000;
        for(int i=0; i<lista.size();i++){

            min = Math.min(min,lista.get(i).getPrecio());

        }
        System.out.println("El vehiculo más barato es: "+min+" $");
        System.out.println("--------------------------------------------------------------------------");

        System.out.println(" ");
        System.out.println("DETALLES DE TODOS LOS VEHÍCULOS: ");
        obj1.DetallesAuto();
        obj2.DetallesAuto();
        obj3.DetallesAuto();



    }
}
