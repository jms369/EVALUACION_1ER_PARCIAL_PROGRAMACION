package Ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        EMPLEADO obj = new EMPLEADO("Maui",26,1700.00);
        EMPLEADO obj1 = new EMPLEADO("Patricio",23,1700.00);
        EMPLEADO obj2 = new EMPLEADO("Jonas",28,5000.00);

        List <EMPLEADO>lista = new ArrayList<EMPLEADO>();
        lista.add(obj);
        lista.add(obj1);
        lista.add(obj2);

        for(int i=0; i<lista.size();i++){
           if (lista.get(i).salario<=3000){

               double res;
               res = obj.Aumento(lista.get(i).salario);
               System.out.println(lista.get(i).nombre+" obtuvo un incremento, su nuevo salario es: "+res);
           }
           else{
               System.out.println(lista.get(i).nombre+" no califica para el aumento");
           }

        }

    }
}

